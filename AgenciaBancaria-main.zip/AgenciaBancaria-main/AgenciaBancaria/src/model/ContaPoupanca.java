package model;

public class ContaPoupanca extends Conta {

	public ContaPoupanca(Pessoa pessoa) {
        super(pessoa);
}

}
