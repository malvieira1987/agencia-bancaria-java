package model;

public class ContaCorrente extends Conta {

	public ContaCorrente(Pessoa pessoa) {
        super(pessoa);
    }
}
